package com.github.intelinos.io;

import com.github.intelinos.calendar.CalendarApp;

import java.util.Scanner;

public class InputHandler {

    public void invoke(Scanner scanner) throws Exception{
        System.out.print("Введите год (после 1600 года): ");
        String input = scanner.nextLine().trim();
        int year = Integer.parseInt(input);
        if (year <= 1600){
            throw new Exception();
        }
        CalendarApp calendar = new CalendarApp();
        calendar.setYear(year);
        calendar.printCalendar();
    }

}
