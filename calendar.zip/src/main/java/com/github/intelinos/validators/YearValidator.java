package com.github.intelinos.validators;

public class YearValidator {
}
