package com.github.intelinos.validators;

public interface Validator {
}
