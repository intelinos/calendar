package com.github.intelinos;

import com.github.intelinos.io.InputHandler;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        InputHandler inputHandler = new InputHandler();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            try {
                inputHandler.invoke(scanner);
            } catch (Exception e) {
                System.out.println("Ошибка: " + e.getMessage());
            }
        }
    }
}