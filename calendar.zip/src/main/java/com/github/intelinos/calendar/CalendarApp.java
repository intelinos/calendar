package com.github.intelinos.calendar;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;

public class CalendarApp {
    private int year;

    private Month[] months = new Month[12];

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    private Month[] getMonths() {
        for (int i = 0; i < months.length; i++) {
            months[i] = new Month();
            Week[] weeks = months[i].getWeeks();

            for (int k = 0; k < weeks.length; k++) {
                weeks[k] = new Week();
            }

            int weekIndx = 0;
            int dowIndx = LocalDate.of(year, i + 1, 1).getDayOfWeek().getValue() - 1; // dow stands for Day Of Week
            int totalDays = YearMonth.of(year, i + 1).lengthOfMonth();
            for (int j = 1; j <= totalDays; j++) {
                weeks[weekIndx].getDays()[dowIndx] = j;
                dowIndx++;
                if (dowIndx > 6) {
                    dowIndx = 0;
                    weekIndx++;
                }
            }
        }

        return months;
    }

    public void printCalendar() {
        getMonths();
        String[] monthNames = {"Январь", "Февраль", "Март", "Апрель", "Май",
                "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"};

        for (int i = 0; i < months.length; i++) {
            System.out.println("\n    " + monthNames[i] + " " + year + "    ");
            System.out.println("Пн Вт Ср Чт Пт Сб Вс");
            for (Week week : months[i].getWeeks()) {
                for (Integer day : week.getDays()) {
                    if (day == null) {
                        System.out.print("   ");
                    } else {
                        System.out.printf("%2d ", day); // чтобы число занимало ровно 2 места
                    }
                }
                System.out.println();
            }
        }
    }

}
