package com.github.intelinos.calendar;

public class CalendarData {
    private int year;

    private Month[] month;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Month[] getMonth() {
        return month;
    }

    public void setMonth(Month[] month) {
        this.month = month;
    }
}
